<?php
Class access.model extend model.class
//Класс access расширяет model.class
{

}