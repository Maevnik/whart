<?php /* Smarty version Smarty-3.1.21-dev, created on 2015-01-29 00:58:35
         compiled from "./templates/header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:47143508054c95b8bdfba93-94206641%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5affcfff2ca2168448d4c7a82668d621776fbfc4' => 
    array (
      0 => './templates/header.tpl',
      1 => 1422482275,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '47143508054c95b8bdfba93-94206641',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'title' => 0,
    'Name' => 1,
  ),
  'has_nocache_code' => true,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_54c95b8be036c0_35120813',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54c95b8be036c0_35120813')) {function content_54c95b8be036c0_35120813($_smarty_tpl) {?><HTML>
<HEAD>
    <TITLE><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
 - <?php echo '/*%%SmartyNocache:47143508054c95b8bdfba93-94206641%%*/<?php echo $_smarty_tpl->tpl_vars[\'Name\']->value;?>
/*/%%SmartyNocache:47143508054c95b8bdfba93-94206641%%*/';?>
</TITLE>
</HEAD>
<BODY bgcolor="#ffffff">
<?php }} ?>
