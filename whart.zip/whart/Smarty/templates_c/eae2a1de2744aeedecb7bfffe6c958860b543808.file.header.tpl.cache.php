<?php /* Smarty version Smarty-3.1.21-dev, created on 2015-01-29 00:18:18
         compiled from "./templates/header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:179299308554c9521a519ae0-44313238%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'eae2a1de2744aeedecb7bfffe6c958860b543808' => 
    array (
      0 => './templates/header.tpl',
      1 => 1413688876,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '179299308554c9521a519ae0-44313238',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'title' => 0,
    'Name' => 1,
  ),
  'has_nocache_code' => true,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_54c9521a521ec1_53428060',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54c9521a521ec1_53428060')) {function content_54c9521a521ec1_53428060($_smarty_tpl) {?><HTML>
<HEAD>
    <TITLE><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
 - <?php echo '/*%%SmartyNocache:179299308554c9521a519ae0-44313238%%*/<?php echo $_smarty_tpl->tpl_vars[\'Name\']->value;?>
/*/%%SmartyNocache:179299308554c9521a519ae0-44313238%%*/';?>
</TITLE>
</HEAD>
<BODY bgcolor="#ffffff">
<?php }} ?>
