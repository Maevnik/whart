<?php /* Smarty version Smarty-3.1.21-dev, created on 2015-01-29 00:18:18
         compiled from "./templates/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:177341072554c9521a528276-67103821%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a27e2a09fe74bec60e04e82e10decfe2329c25eb' => 
    array (
      0 => './templates/footer.tpl',
      1 => 1413688876,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '177341072554c9521a528276-67103821',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_54c9521a529cc0_63068088',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54c9521a529cc0_63068088')) {function content_54c9521a529cc0_63068088($_smarty_tpl) {?></BODY>
</HTML>
<?php }} ?>
