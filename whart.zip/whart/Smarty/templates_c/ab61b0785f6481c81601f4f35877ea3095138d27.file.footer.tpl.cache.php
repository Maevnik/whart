<?php /* Smarty version Smarty-3.1.21-dev, created on 2015-01-29 00:58:35
         compiled from "./templates/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:180103113154c95b8be08864-63092764%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ab61b0785f6481c81601f4f35877ea3095138d27' => 
    array (
      0 => './templates/footer.tpl',
      1 => 1422482275,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '180103113154c95b8be08864-63092764',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_54c95b8be09b44_78460726',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54c95b8be09b44_78460726')) {function content_54c95b8be09b44_78460726($_smarty_tpl) {?></BODY>
</HTML>
<?php }} ?>
