<?php $_config_vars = array (
  'sections' => 
  array (
    'setup' => 
    array (
      'vars' => 
      array (
        'bold' => true,
      ),
    ),
  ),
  'vars' => 
  array (
    'title' => 'GO TO HELL!',
    'cutoff_size' => 40,
  ),
); ?>