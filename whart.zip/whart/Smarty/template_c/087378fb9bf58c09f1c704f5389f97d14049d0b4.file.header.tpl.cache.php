<?php /* Smarty version Smarty-3.1.21-dev, created on 2015-01-29 01:10:36
         compiled from "./Smarty/templates/header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:198778444354c95e5c2afcc5-01491522%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '087378fb9bf58c09f1c704f5389f97d14049d0b4' => 
    array (
      0 => './Smarty/templates/header.tpl',
      1 => 1422482275,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '198778444354c95e5c2afcc5-01491522',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'title' => 0,
    'Name' => 1,
  ),
  'has_nocache_code' => true,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_54c95e5c302276_89911863',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54c95e5c302276_89911863')) {function content_54c95e5c302276_89911863($_smarty_tpl) {?><HTML>
<HEAD>
    <TITLE><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
 - <?php echo '/*%%SmartyNocache:198778444354c95e5c2afcc5-01491522%%*/<?php echo $_smarty_tpl->tpl_vars[\'Name\']->value;?>
/*/%%SmartyNocache:198778444354c95e5c2afcc5-01491522%%*/';?>
</TITLE>
</HEAD>
<BODY bgcolor="#ffffff">
<?php }} ?>
