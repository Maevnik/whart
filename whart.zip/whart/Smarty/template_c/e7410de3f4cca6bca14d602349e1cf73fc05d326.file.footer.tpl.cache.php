<?php /* Smarty version Smarty-3.1.21-dev, created on 2015-01-29 01:10:36
         compiled from "./Smarty/templates/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:34228928554c95e5c3078f2-17572739%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e7410de3f4cca6bca14d602349e1cf73fc05d326' => 
    array (
      0 => './Smarty/templates/footer.tpl',
      1 => 1422482275,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '34228928554c95e5c3078f2-17572739',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_54c95e5c308c03_37396839',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54c95e5c308c03_37396839')) {function content_54c95e5c308c03_37396839($_smarty_tpl) {?></BODY>
</HTML>
<?php }} ?>
