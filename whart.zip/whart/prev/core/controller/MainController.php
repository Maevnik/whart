<?php
class MainController
{
    public function __construct() {
        echo 'DummyController</br>';
    }
    public function aboutController()
    {
        echo 'This is dummy controller</br>';
    }
    public function indexAction()
    {
        echo 'INDEX ACTION</br>';
    }
}